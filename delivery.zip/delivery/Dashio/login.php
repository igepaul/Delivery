<?php
session_start();
if(isset($_SESSION['userId']) != "") {
	header("Location: index.php");
}

if(isset($_POST['btn-signup'])) {
  include 'connect.php';
  $fullname = $_POST['fullname'];
  $email = $_POST['email'];
  $password = $_POST['password'];
  $phone = $_POST['phone'];
  $country = $_POST['country'];
  $state = $_POST['state'];
  $city = $_POST['city'];
  $address = $_POST['address'];
  $role = 'user';
  $created = date("Y-m-d H:i:s");
  $last_login = date("Y-m-d H:i:s");

  $check_query= "SELECT * FROM user WHERE email='$email'";
	
  $check = mysqli_query($con, $check_query) or die();
  $count = mysqli_num_rows($check);
  
  if ($count != 1) {
    $sql = "INSERT INTO user(name,email,password,phone,city,country,state,address,created,last_login,role) VALUES ('$fullname', '$email', '$password', '$phone', '$city', '$country', '$state', '$address', '$created', '$last_login', '$role')";
    $result = mysqli_query($con, $sql);

    if($result){
      echo '<script>alert("New record created")</script>';
      echo '<script> window.location = "../index.php"</script>';

    } else {
      echo "Error: " . $sql . "<br>" . mysqli_error($con);
      echo '<script>alert("Error")</script>';
    }
  } else {
    echo '<script>alert("Account Already Exist")</script>';
    echo "Error: " . $check_query . "<br>" . mysqli_error($con);  
    echo '<script> window.location = "login.php"</script>';
  }
  
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>Dashio - Bootstrap Admin Template</title>

  <!-- Favicons -->
  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="//geodata.solutions/includes/countrystatecity.js"></script>
  
</head>

<body>
  
  <div id="login-page">
    <div class="container">
      <form class="form-login" action="" method="post">
        <h2 class="form-login-heading">Sign Up</h2>
        <div class="login-wrap">
          <div class="group_login_input">
            <input type="text" name="fullname" class="form-control" placeholder="Full Name" autofocus>
            <input type="email" name="email" class="form-control" placeholder="Email" autofocus>
          </div>
          <div class="group_login_input">
            <input type="password" name="password" class="form-control" placeholder="Password" autofocus>
            <input type="phone" name="phone" class="form-control" placeholder="Phone" autofocus>
          </div>
          <div class="group_login_input">
            <select name="country" class="countries form-control" id="countryId">
              <option value="">Select Country</option>
            </select>
            <select name="state" class="states form-control" id="stateId">
              <option value="">Select State</option>
            </select>
          </div>
          <div class="group_login_input">
            <select name="city" class="cities form-control" id="cityId">
              <option value="">Select City</option>
            </select>
            <input type="text" name="address" class="form-control" placeholder="Address" autofocus>
          </div>

          <br>
          <button class="btn btn-theme btn-block" name="btn-signup" type="submit"><i class="fa fa-lock"></i> SIGN IN</button>
          <hr>
        
          <div class="registration">
            Have an account?<br/>
            <a class="" href="../index.php">Sign in</a>
          </div>
        </div>
      </form>
    </div>
  </div>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.min.js"></script>
  <!--BACKSTRETCH-->
  <!-- You can use an image of whatever size. This script will stretch to fit in any screen size.-->
  <script type="text/javascript" src="lib/jquery.backstretch.min.js"></script>
  <script>
    $.backstretch("img/login-bg.jpg", {
      speed: 500
    });
  </script>
</body>

</html>
