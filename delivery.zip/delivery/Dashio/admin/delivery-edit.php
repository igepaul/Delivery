<?php
session_start();
if(!isset($_SESSION["name"])){
 header("Location: ../index.php");
}

if (isset($_GET['order_id'])) {
  include ('connect.php');

  $id = $_GET['order_id'];

  $sql="SELECT * FROM delivery WHERE id='$id'";
  $result=  mysqli_query($con,$sql) or die(mysqli_error($con));

  if (!$result) {
    echo "Error: " . $result . "<br>" . mysqli_error($con); 
  } else {
    $rws=  mysqli_fetch_array($result);
    $shipping_method = $rws['shipping_method'];
    $shipping_mode = $rws['shipping_mode'];
    $package_type = $rws['package_type'];
    $shipping_insurance = $rws['shipping_insurance'];
    $sender_email = $rws['sender_email'];

    $weight = $rws['weight'];
    $height = $rws['height'];
    $volume = $rws['volume'];
    $quantity = $rws['quantity'];

    $created = $rws['created'];
    $tracking = $rws['tracking'];
    $description = $rws['description'];
    $status = $rws['status'];
    $total = $rws['total'];

    
    $reciever_name = $rws['receiver_name'];
    $reciever_email = $rws['receiver_email'];
    $reciever_phone = $rws['receiver_phone'];
    $reciever_country = $rws['receiver_country'];
    $reciever_state = $rws['receiver_state'];
    $reciever_city = $rws['receiver_city'];
    $reciever_address = $rws['receiver_address'];
  }
  
} else {
  echo "Something went wrong!";
  exit;
}

if(isset($_POST['btn-delivery-edit'])) {
  include 'connect.php';

  $id = $_GET['order_id'];
  $shipping_method = $_POST['shipping_method'];
  $shipping_mode = $_POST['shipping_mode'];
  $package_type = $_POST['package_type'];
  $weight = $_POST['weight'];
  $volume = $_POST['volume'];
  $height = $_POST['height'];
  $quantity = $_POST['quantity'];
  $description = $_POST['description'];
  $shipping_insurance = $_POST['shipping_insurance'];

  $reciever_name = $_POST['reciever_name'];
  $reciever_email = $_POST['reciever_email'];
  $reciever_phone = $_POST['reciever_phone'];
  $reciever_country = $_POST['reciever_country'];
  $reciever_state = $_POST['reciever_state'];
  $reciever_city = $_POST['reciever_city'];
  $reciever_address = $_POST['reciever_address'];
  
  $tracking = $_POST['tracking'];
  $total = $_POST['total'];
  $status = $_POST['status'];

  $sql = "UPDATE delivery SET 
  shipping_method='$shipping_method',
  shipping_mode='$shipping_mode',
  package_type='$package_type',
  weight='$weight',
  volume='$volume',
  height='$height',
  quantity='$quantity',
  description='$description',
  shipping_insurance='$shipping_insurance',
  receiver_name='$reciever_name',
  receiver_email='$reciever_email',
  receiver_phone='$reciever_phone',
  receiver_country='$reciever_country',
  receiver_state='$reciever_state',
  receiver_city='$reciever_city',
  receiver_address='$reciever_address', 
  status='$status',
  tracking='$tracking',
  total='$total' WHERE id='$id'";

  $result = mysqli_query($con, $sql);

  if($result){
    echo "<script>alert('Record Updated')</script>";
    echo '<script> window.location = "delivery.php"</script>';

  } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($con);
    echo "<script>alert('Something went wrong')</script>";
    echo '<script> window.location = "delivery.php"</script>';
  }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>Dashio - Bootstrap Admin Template</title>

  <!-- Favicons -->
  <link href="img/favicon.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="//geodata.solutions/includes/countrystatecity.js"></script>
  
  <!-- =======================================================
    Template Name: Dashio
    Template URL: https://templatemag.com/dashio-bootstrap-admin-template/
    Author: TemplateMag.com
    License: https://templatemag.com/license/
  ======================================================= -->
</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
      </div>
      <!--logo start-->
      <a href="index.html" class="logo"><b>DASH<span>IO</span></b></a>
      <!--logo end-->
      <div class="nav notify-row" id="top_menu">
        <!--  notification start -->
        <ul class="nav top-menu">
          <!-- settings start -->
          <li class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="index.html#">
              <i class="fa fa-tasks"></i>
              <span class="badge bg-theme">4</span>
              </a>
            <ul class="dropdown-menu extended tasks-bar">
              <div class="notify-arrow notify-arrow-green"></div>
              <li>
                <p class="green">You have 4 pending tasks</p>
              </li>
              <li>
                <a href="index.html#">
                  <div class="task-info">
                    <div class="desc">Dashio Admin Panel</div>
                    <div class="percent">40%</div>
                  </div>
                  <div class="progress progress-striped">
                    <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%">
                      <span class="sr-only">40% Complete (success)</span>
                    </div>
                  </div>
                </a>
              </li>
              <li>
                <a href="index.html#">
                  <div class="task-info">
                    <div class="desc">Database Update</div>
                    <div class="percent">60%</div>
                  </div>
                  <div class="progress progress-striped">
                    <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%">
                      <span class="sr-only">60% Complete (warning)</span>
                    </div>
                  </div>
                </a>
              </li>
              <li>
                <a href="index.html#">
                  <div class="task-info">
                    <div class="desc">Product Development</div>
                    <div class="percent">80%</div>
                  </div>
                  <div class="progress progress-striped">
                    <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%">
                      <span class="sr-only">80% Complete</span>
                    </div>
                  </div>
                </a>
              </li>
              <li>
                <a href="index.html#">
                  <div class="task-info">
                    <div class="desc">Payments Sent</div>
                    <div class="percent">70%</div>
                  </div>
                  <div class="progress progress-striped">
                    <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width: 70%">
                      <span class="sr-only">70% Complete (Important)</span>
                    </div>
                  </div>
                </a>
              </li>
              <li class="external">
                <a href="#">See All Tasks</a>
              </li>
            </ul>
          </li>
          <!-- settings end -->
          <!-- inbox dropdown start-->
          <li id="header_inbox_bar" class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="index.html#">
              <i class="fa fa-envelope-o"></i>
              <span class="badge bg-theme">5</span>
              </a>
            <ul class="dropdown-menu extended inbox">
              <div class="notify-arrow notify-arrow-green"></div>
              <li>
                <p class="green">You have 5 new messages</p>
              </li>
              <li>
                <a href="index.html#">
                  <span class="photo"><img alt="avatar" src="img/ui-zac.jpg"></span>
                  <span class="subject">
                  <span class="from">Zac Snider</span>
                  <span class="time">Just now</span>
                  </span>
                  <span class="message">
                  Hi mate, how is everything?
                  </span>
                  </a>
              </li>
              <li>
                <a href="index.html#">
                  <span class="photo"><img alt="avatar" src="img/ui-divya.jpg"></span>
                  <span class="subject">
                  <span class="from">Divya Manian</span>
                  <span class="time">40 mins.</span>
                  </span>
                  <span class="message">
                  Hi, I need your help with this.
                  </span>
                  </a>
              </li>
              <li>
                <a href="index.html#">
                  <span class="photo"><img alt="avatar" src="img/ui-danro.jpg"></span>
                  <span class="subject">
                  <span class="from">Dan Rogers</span>
                  <span class="time">2 hrs.</span>
                  </span>
                  <span class="message">
                  Love your new Dashboard.
                  </span>
                  </a>
              </li>
              <li>
                <a href="index.html#">
                  <span class="photo"><img alt="avatar" src="img/ui-sherman.jpg"></span>
                  <span class="subject">
                  <span class="from">Dj Sherman</span>
                  <span class="time">4 hrs.</span>
                  </span>
                  <span class="message">
                  Please, answer asap.
                  </span>
                  </a>
              </li>
              <li>
                <a href="index.html#">See all messages
                  </a>
              </li>
            </ul>
          </li>
          <!-- inbox dropdown end -->
          <!-- notification dropdown start-->
          <li id="header_notification_bar" class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="index.html#">
              <i class="fa fa-bell-o"></i>
              <span class="badge bg-warning">7</span>
              </a>
            <ul class="dropdown-menu extended notification">
              <div class="notify-arrow notify-arrow-yellow"></div>
              <li>
                <p class="yellow">You have 7 new notifications</p>
              </li>
              <li>
                <a href="index.html#">
                  <span class="label label-danger"><i class="fa fa-bolt"></i></span> Server Overloaded.
                  <span class="small italic">4 mins.</span>
                  </a>
              </li>
              <li>
                <a href="index.html#">
                  <span class="label label-warning"><i class="fa fa-bell"></i></span> Memory #2 Not Responding.
                  <span class="small italic">30 mins.</span>
                  </a>
              </li>
              <li>
                <a href="index.html#">
                  <span class="label label-danger"><i class="fa fa-bolt"></i></span> Disk Space Reached 85%.
                  <span class="small italic">2 hrs.</span>
                  </a>
              </li>
              <li>
                <a href="index.html#">
                  <span class="label label-success"><i class="fa fa-plus"></i></span> New User Registered.
                  <span class="small italic">3 hrs.</span>
                  </a>
              </li>
              <li>
                <a href="index.html#">See all notifications</a>
              </li>
            </ul>
          </li>
          <!-- notification dropdown end -->
        </ul>
        <!--  notification end -->
      </div>
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
          <li>
            <a class="logout" href="logout.php">Logout</a>
          </li>
        </ul>
      </div>
    </header>
    <!--header end-->
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
          <p class="centered"><a href="profile.html"><img src="img/ui-sam.jpg" class="img-circle" width="80"></a></p>
          <h5 class="centered"><?php echo $_SESSION['name'];?>  </h5>
          <h5 class="centered"><?php echo $_SESSION['role'];?>  </h5>
          <li class="mt">
            <a href="index.php">
              <i class="fa fa-dashboard"></i>
              <span>Dashboard</span>
              </a>
          </li>
          <li class="mt">
            <a class="active" href="delivery.php">
              <i class="fa fa-dashboard"></i>
              <span>Deliveries</span>
              </a>
          </li>
          <li class="mt">
            <a href="user.php">
              <i class="fa fa-dashboard"></i>
              <span>User</span>
              </a>
          </li>
          <li class="mt">
            <a href="profile.php">
              <i class="fa fa-dashboard"></i>
              <span>Profile</span>
              </a>
          </li>
        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>
    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
     <!--main content start-->
     <section id="main-content">
      <section class="wrapper">
        <h3><i class="fa fa-angle-right"></i> Create</h3>

        <!-- BASIC FORM ELELEMNTS -->
        <div class="row mt">
          <div class="col-lg-12">
            <div class="form-panel">
              <h4 class="mb"><i class="fa fa-angle-right"></i> Sender information</h4>
              <form class="form-horizontal style-form" method="post">
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Shipping Method</label>
                  <div class="col-sm-10">
                    <select class="form-control" name="shipping_method">
                      <option value="<?php echo $shipping_method;?>"> <?php echo $shipping_method; ?></option>
                      <option value="air">Air</option>
                      <option value="land">Land</option>
                      <option value="sea">Sea</option>
                    </select>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Shipping Mode</label>
                  <div class="col-sm-10">
                    <select class="form-control" name="shipping_mode">
                      <option value="<?php echo $shipping_mode;?>"> <?php echo $shipping_mode; ?></option>
                      <option value="cargo">Cargo</option>
                      <option value="express">Express</option>
                      <option value="express-cargo">Express Cargo</option>
                    </select>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Package Type</label>
                  <div class="col-sm-10">
                    <select value="<?php echo $package_type;?>" class="form-control" name="package_type">
                      <option value="<?php echo $package_type;?>"> <?php echo $package_type; ?></option>
                      <option value="box">Bus</option>
                      <option value="envelope">Envelope</option>
                      <option value="container">Container</option>
                    </select>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Weight(Kg)</label>
                  <div class="col-sm-10">
                    <input type="number" value="<?php echo $weight;?>" name="weight" class="form-control">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Height(m)</label>
                  <div class="col-sm-10">
                    <input type="number" value="<?php echo $height;?>" name="height" class="form-control">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Volume(m3)</label>
                  <div class="col-sm-10">
                    <input type="number" value="<?php echo $volume;?>" name="volume" class="form-control">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Quantity</label>
                  <div class="col-sm-10">
                    <input type="number" value="<?php echo $quantity;?>" name="quantity" class="form-control">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Description</label>
                  <div class="col-sm-10">
                    <input type="text"  value="<?php echo $description;?>" name="description" class="form-control">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Shipping Insurance</label>
                  <div class="col-sm-10">
                    <select value="<?php echo $shipping_insurance;?>" class="form-control" name="shipping_insurance">
                      <option value="exclusive">Exclusive</option>
                      <option value="premium">Premium</option>
                    </select>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Status</label>
                  <div class="col-sm-10">
                    <select class="form-control" name="status">
                      <option value="<?php echo $status;?>"> <?php echo $status; ?></option>
                      <option value="pending">Pending</option>
                      <option value="loading">Loading</option>
                      <option value="in-transit">In Transit</option>
                      <option value="custom-check">Custom Check</option>
                      <option value="landed">Landed</option>
                      <option value="clearing">Clearing</option>
                      <option value="delivered">Delivered</option>
                    </select>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Tracking</label>
                  <div class="col-sm-10">
                    <input type="number" value="<?php echo $tracking;?>" name="tracking" class="form-control">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Total</label>
                  <div class="col-sm-10">
                    <input type="number" value="<?php echo $total;?>" name="total" class="form-control">
                  </div>
                </div>
            </div>
          </div>
        </div>

        <div class="row mt">
          <div class="col-lg-12">
            <div class="form-panel">
              <h4 class="mb"><i class="fa fa-angle-right"></i> Reciever information</h4>
              <div class="form-horizontal style-form" >
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Name</label>
                  <div class="col-sm-10">
                    <input type="text" value="<?php echo $reciever_name;?>" name="reciever_name" class="form-control">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Email</label>
                  <div class="col-sm-10">
                    <input type="email" value="<?php echo $reciever_email;?>" name="reciever_email" class="form-control">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Phone</label>
                  <div class="col-sm-10">
                    <input type="phone" value="<?php echo $reciever_phone;?>" name="reciever_phone" class="form-control">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Country</label>
                  <div class="col-sm-10">
                  <select name="reciever_country" class="countries form-control" id="countryId">
                    <option value="<?php echo $reciever_country;?>"> <?php echo $reciever_country; ?></option>
                    <option value="">Select Country</option>
                  </select>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">State</label>
                  <div class="col-sm-10">
                  <select name="reciever_state" class="states form-control" id="stateId">
                    <option value="<?php echo $reciever_state;?>"> <?php echo $reciever_state; ?></option>
                    <option value="">Select State</option>
                  </select>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">City</label>
                  <div class="col-sm-10">
                  <select name="reciever_city" class="cities form-control" id="cityId">
                    <option value="<?php echo $reciever_city;?>"> <?php echo $reciever_city; ?></option>
                    <option value="">Select City</option>
                  </select>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 col-sm-2 control-label">Address</label>
                  <div class="col-sm-10">
                    <input type="text" value="<?php echo $reciever_address;?>" name="reciever_address" class="form-control">
                  </div>
                </div>
                
                <button type="submit" name="btn-delivery-edit" class="btn btn-theme">Edit Orders</button>
              </form>

              
            </div>
            
          </div>
          
          <!-- col-lg-12-->
        </div>
        <!-- /row -->
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
    <!--footer start-->
    <footer class="site-footer">
      <div class="text-center">
        <p>
          &copy; Copyrights <strong>Dashio</strong>. All Rights Reserved
        </p>
        <div class="credits">
          <!--
            You are NOT allowed to delete the credit link to TemplateMag with free version.
            You can delete the credit link only if you bought the pro version.
            Buy the pro version with working PHP/AJAX contact form: https://templatemag.com/dashio-bootstrap-admin-template/
            Licensing information: https://templatemag.com/license/
          -->
          Created with Dashio template by <a href="https://templatemag.com/">TemplateMag</a>
        </div>
        <a href="basic_table.html#" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
    </footer>
    <!--footer end-->
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.min.js"></script>
  <script class="include" type="text/javascript" src="lib/jquery.dcjqaccordion.2.7.js"></script>
  <script src="lib/jquery.scrollTo.min.js"></script>
  <script src="lib/jquery.nicescroll.js" type="text/javascript"></script>
  <!--common script for all pages-->
  <script src="lib/common-scripts.js"></script>
  <!--script for this page-->
  
</body>

</html>