<?php
$mysql_hostname = "localhost";
$mysql_user = "firstfr1_delivery";
$mysql_password = 'gyP~EiLkqhXg';
$mysql_database = "firstfr1_delivery";

$con = mysqli_connect($mysql_hostname, $mysql_user, $mysql_password, $mysql_database) 

or die("Oops some thing went wrong");

?>

<!-- <?php
// $con = new mysqli("localhost", "root", "root", "deliveryPortal");
$con = new mysqli("localhost", "firstfr1_delivery", "gyP~EiLkqhXg", "firstfr1_delivery");
if ($con->connect_error) {
  echo "ERROR: Unable to connect: " . $con->connect_error;
}

echo 'Connected to the database.<br>';
?> -->