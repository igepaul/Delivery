<?php
    session_start();

    if(!(isset($_SESSION['name']))) {
        header('location: index.php');
    }
    include("connect.php");

    if (isset($_GET['delete'])) {
        $id = $_GET['delete'];
        $record = mysqli_query($con, "SELECT * FROM delivery WHERE id=$id");
        if (count($record) == 1 ) {
            $query = "DELETE FROM delivery WHERE id='$id'";
            $res = mysqli_query($con, $query);
            if($res) {
                echo '<script>alert("Deleted successfully!")</script>';
                echo '<script> window.location = "delivery.php"</script>';
            } else {
                echo "Error: " . $query . "<br>" . mysqli_error($con);
            }
        }      
        
    } else {
        echo "Something went wrong!";
        exit;
    }
?>