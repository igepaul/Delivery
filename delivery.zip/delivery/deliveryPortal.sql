-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Nov 18, 2019 at 08:18 AM
-- Server version: 5.7.26
-- PHP Version: 7.3.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `deliveryPortal`
--

-- --------------------------------------------------------

--
-- Table structure for table `delivery`
--

CREATE TABLE `delivery` (
  `id` int(11) NOT NULL,
  `shipping_method` varchar(30) NOT NULL,
  `shipping_mode` varchar(30) NOT NULL,
  `package_type` varchar(30) NOT NULL,
  `weight` int(11) NOT NULL,
  `volume` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `description` varchar(100) DEFAULT NULL,
  `shipping_insurance` varchar(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `sender_email` varchar(30) NOT NULL,
  `sender_address` varchar(255) NOT NULL,
  `receiver_name` varchar(255) NOT NULL,
  `receiver_email` varchar(255) NOT NULL,
  `receiver_phone` varchar(100) NOT NULL,
  `receiver_country` varchar(100) NOT NULL,
  `receiver_state` varchar(100) NOT NULL,
  `receiver_city` varchar(100) NOT NULL,
  `receiver_address` varchar(100) NOT NULL,
  `status` varchar(11) DEFAULT NULL,
  `tracking` varchar(30) DEFAULT NULL,
  `created` datetime NOT NULL,
  `total` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `delivery`
--

INSERT INTO `delivery` (`id`, `shipping_method`, `shipping_mode`, `package_type`, `weight`, `volume`, `height`, `quantity`, `description`, `shipping_insurance`, `sender_id`, `sender_email`, `sender_address`, `receiver_name`, `receiver_email`, `receiver_phone`, `receiver_country`, `receiver_state`, `receiver_city`, `receiver_address`, `status`, `tracking`, `created`, `total`) VALUES
(5, 'air', 'cargo', 'bus', 22, 322, 332, 3, 'sasassas', 'exclusive', 1, 'test@test.com', '12 Oduduwa Street', 'Chinedu Ohagwu', 'csdsdsd@sdsdss.com', '12122121212', '', '', '', '12 Oduduwa Street', 'delivered', '83727183', '2019-11-15 15:34:23', '2200'),
(6, 'air', 'cargo', 'bus', 78, 1, 123, 23, 'Jealous', 'exclusive', 1, 'test@test.com', '12 Oduduwa Street', 'Chinedu Ohagwu', 'csdsdsd@sdsdss.com', '12122121212', 'Algeria', '', 'Boudjima', '12 Oduduwa Street', 'pending', '58150919', '2019-11-15 15:35:46', '2200'),
(8, 'sea', 'express', 'envelope', 12, 12, 4, 10, 'A Local annestetics', 'premium', 1, 'test@test.com', '12 Oduduwa Street', 'Peter Nwankwo', 'peter.nwankwo@gmail.com', '0918232234', '', '', '', '12 Oduduwa Street', 'pending', '69172602', '2019-11-16 11:36:39', '202'),
(10, 'land', 'express', 'bus', 34, 12, 32, 21, 'Value in Necessity', 'exclusive', 3, 'admin@admin.com', 'admin', 'Okomu Michael', 'okomu.michael@gmail.com', '0912832454', '', '', '', 'Layinka Road', 'delivered', '19674014', '2019-11-16 13:22:43', '334'),
(12, 'sea', 'express', 'envelope', 23, 32, 124, 23, 'A local film', 'premium', 3, 'admin@admin.com', 'admin', 'Peter Nnam', 'pero@gmail.com', '0912823423', '', '', '', '12 Oduduwa Street', 'pending', '90694295', '2019-11-16 22:43:08', '818');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `city` varchar(30) NOT NULL,
  `country` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `created` datetime DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `role` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password`, `phone`, `city`, `country`, `state`, `address`, `created`, `last_login`, `role`) VALUES
(1, 'Chinedu Ohagwu', 'test@test.com', 'password', '08165391233', 'Bogove', 'Albania', 'Berat', '12 Oduduwa Street', '2019-11-14 00:00:00', '2019-11-14 00:00:00', 'user'),
(3, 'Chinedu Ohagwu', 'admin@admin.com', 'admin', '08123456789', 'admin', 'admin', 'admin', '12 Oduduwa Street', '2019-11-14 07:00:00', '2019-11-14 00:00:00', 'admin'),
(9, 'Charles Ekeugo', 'charles.ekeugo@gmail.com', 'password', '+2348160474664', '', '', '', '4 Ojoh Lane, Layinka, Ajegunle, Apapa', '2019-11-16 22:14:54', NULL, 'user'),
(11, 'Chibuike Ohagwu', 'chibuike.ohagwu@gmail.com', 'chibuike.ohagwu@gmail.com', '+2348160474664', '', '', '', '12 Oduduwa Street', '2019-11-16 22:53:21', NULL, 'user'),
(12, 'Emeka Ogboche', 'emeka.ogboche@gmail.com', 'password', '+2348160474664', '', '', '', '12 Oduduwa Street', '2019-11-16 22:54:56', NULL, 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `delivery`
--
ALTER TABLE `delivery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `delivery`
--
ALTER TABLE `delivery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
